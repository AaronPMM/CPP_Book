Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   add_item         add       
   count-size       newcount-size
   count-size       fcnobj
   word_echo        readStr

Programs not listed above print output and do
not read any input

