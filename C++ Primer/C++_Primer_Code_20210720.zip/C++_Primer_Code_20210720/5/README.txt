Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   add_item_data    add_item2
   doWhile          doWhile
   grades           ifgrades
   guesses          guess
   readme           othercnt
   readme           vowels 

Programs not listed above print output and do
not read any input

