Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   storyDatafile    wcEx
   storyDatafile    erasemap
   storyDatafile    pair
   storyDatafile    word_count
   word_count       restricted_count
   word_count       unorderedWord_count

Programs not listed above print output and do
not read any input

