Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   add               add_using
   grades            arrayScores
   grades            vecScores
   hexify            hexify
   ptr_traversal2    ptr_traversal2
   string_io         string_io
   string_io2        string_io
   vecStrings2       vecStrings2
   word_echo         getline
   word_echo         string_size2
   word_echo         string_size3
   word_echo         word_echo

Programs not listed above print output and do
not read any input

