//: C02:Concat.cpp
// From Thinking in C++, 2nd Edition
// Available at http://www.BruceEckel.com
// (c) Bruce Eckel 1999
// Copyright notice in Copyright.txt
// Character array Concatenation
#include <iostream>
using namespace std;

int main() {
  cout << "This is far too long to put on a single "
    "line but it can be broken up with no ill effects\n"
    "as long as there is no punctuation separating "
    "adjacent character arrays.\n";
} ///:~
